import React from 'react';
import AppRoutes from '../Routes/AppRoutes.jsx';

const App = () => {
  return <AppRoutes />;
};

export default App;